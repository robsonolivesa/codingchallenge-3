# Uploading files with Multer in Node


## Development server

Run `node server.js` for a dev server. Navigate to `http://localhost:3000/`.

