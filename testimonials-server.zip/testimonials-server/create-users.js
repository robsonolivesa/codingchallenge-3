let users = [
    { "name" : "aaa", "email" : "aaa@aaa.com.br", "password": "aaa" },
];

const JsonDB = require('node-json-db');

let db = new JsonDB("usersDB", true, false);

for( let i = 0; i < users.length; i++ ) {
    db.push("/users/" + users[i].email, users[i]);
}

process.exit(-1);