module.exports = (function() {
    const router = require('express').Router();

    router.use('/auth', require('./auth/auth.routes'));
    
    router.use('/people', require('./people/people.routes'));

    return router;
})();
