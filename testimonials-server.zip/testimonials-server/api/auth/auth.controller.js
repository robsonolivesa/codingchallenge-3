var AuthController = AuthController || {};

const tokenHandler = require('./token-handler');

const JsonDB = require('node-json-db');
let db = new JsonDB("usersDB", true, false);

AuthController.authenticate = function(email, password) {
    return new Promise( (resolve, reject) => {
        if( !password ) return reject('Empty password');
        
        try {
            let user = db.getData('/users/' + email);

            if( user.password != password ) {
                return reject("invalid password");
            }
            
            var options = {
                email: email
            }
            
            let tokens = tokenHandler.generateTokens(options);

            return resolve({
                access_token: tokens[0],
                refresh_token: tokens[1]
            }); 

        } catch(error) {
            reject(error);
        };
    });
}

AuthController.refresh = function(refresh_token) {
    return tokenHandler.generateAccessWithRefresh( refresh_token );
}

AuthController.verify = function( authorization ) {
    try {
        let authParts = authorization.split(' ');
        if( authParts[0] != 'Bearer' ) return false;
        if( !authParts[1] ) return false;

        return tokenHandler.validate(authParts[1]);
    } catch( e ) {
        return false;
    }
}
module.exports = AuthController;

