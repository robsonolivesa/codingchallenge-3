module.exports = (function() {
    const router = require('express').Router();
    const AuthController = require('../auth/auth.controller');
    const PeopleController = require('./people.controller');
    
    router.all('/*', function(req, res, next){
        
        let authHeader = req.headers['authorization'];
        if( !authHeader ) {
            res.status(401);
            return res.send({
                error: "Unauthorized"
            });
        }

        let authData = AuthController.verify(authHeader);

        if( authData && authData != -1 ) {
            req.authData = authData;
            return next();
        } else {
            res.status(401);
            return res.send({
                error: "Unauthorized"
            });
        }
        
    });

    router.get('/', function(req, res, next) {
        let page = req.query.page*1;
        let pageSize = req.query.pageSize*1;
        let name = req.query.name;
        
        let filters = {
            page: page,
            pageSize: pageSize,
            name: name
        }

        return PeopleController.getPeople(filters).then( people => {
            return res.send(people);
        }).catch( err => {
            res.status(400);
            console.log(err);
            return res.send({
                error: err
            });
        });
    });

    router.get('/me', function(req, res, next) {
        return PeopleController.getPerson(req.authData.email).then( person => {
            return res.send(person);
        }).catch( err => {
            res.status(400);
            console.log(err);
            return res.send({
                error: err
            });
        });
    });

    router.put('/me', function(req, res, next) {
        let newName = req.body.name;
        let newPhoto = req.body.photo;

        return PeopleController.updatePerson(req.authData.email, newName, newPhoto).then( person => {
            return res.send(person);
        }).catch( err => {
            res.status(400);
            console.log(err);
            return res.send({
                error: err
            });
        });
    });

    router.get('/:id', function(req, res, next) {
        let email = PeopleController.extractEmailFromId(req.params.id);
        
        return PeopleController.getPerson(email).then( person => {
            return res.send(person);
        }).catch( err => {
            res.status(400);
            console.log(err);
            return res.send({
                error: err
            });
        });
    });

    router.get('/:id/testimonials', function(req, res, next) {
        let page = req.query.page*1;
        let pageSize = req.query.pageSize*1;
        
        let filters = {
            page: page,
            pageSize: pageSize,
            status: 2
        }
        
        let id = req.params.id;
        let buff = new Buffer(id, 'base64');  
        let email = buff.toString('ascii');

        if( req.query.status && email == req.authData.email ) {
            filters.status = req.query.status;
        }
        
        return PeopleController.getTestimonials(email, filters).then( testimonials => {
            return res.send(testimonials);
        }).catch( err => {
            res.status(400);
            console.log(err);
            return res.send({
                error: err
            });
        });
    });

    
    router.post('/:id/testimonials', function(req, res, next) {
        let email = PeopleController.extractEmailFromId(req.params.id);

        let newTestimonial = {
            status : 1,
            text: req.body.text,
            author: req.authData.email,
            authorId: PeopleController.generateId(req.authData.email)
        }

        return PeopleController.createTestimonial(email, newTestimonial).then( testimonial => {
            return res.send(testimonial);
        }).catch( err => {
            res.status(400);
            console.log(err);
            return res.send({
                error: err
            });
        });
    });

    router.put('/:id/testimonials/:idT', function(req, res, next) {
        let email = PeopleController.extractEmailFromId(req.params.id);
        let idT = req.params.idT;

        if( email != req.authData.email ) {
            res.status(403);
            return res.send({
                error: "Bad bad person. It's not your testimonial to approve."
            });
        }

        let status = req.body.status;

        if( !status || status != 2 ) {
            res.status(400);
            return res.send({
                error: "Invalid status"
            });
        }
        
        return PeopleController.approveTestimonial(email, idT).then( response => {
            return res.send(response);
        }).catch( err => {
            res.status(400);
            console.log(err);
            return res.send({
                error: err
            });
        });
    });

    
    router.delete('/:id/testimonials/:idT', function(req, res, next) {
        let email = PeopleController.extractEmailFromId(req.params.id);
        let idT = req.params.idT;

        if( email != req.authData.email ) {
            res.status(403);
            return res.send({
                error: "Bad bad person. It's not your testimonial to delete."
            });
        }
        
        return PeopleController.deleteTestimonial(email, idT).then( response => {
            return res.send(response);
        }).catch( err => {
            res.status(400);
            console.log(err);
            return res.send({
                error: err
            });
        });
    });

    return router;
})();
