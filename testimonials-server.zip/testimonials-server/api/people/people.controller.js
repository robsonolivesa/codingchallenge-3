var PeopleController = PeopleController || {};

const JsonDB = require('node-json-db');
let db = new JsonDB("usersDB", true, false);
var _ = require('lodash');

PeopleController.generateId = function(email) {
    return (new Buffer(email) ).toString('base64')
}

PeopleController.extractEmailFromId = function( id ) {
    return (new Buffer(id, 'base64')).toString('ascii');
}

PeopleController.getPeople = function (filters) {

    return new Promise( (resolve, reject) => {
        
        if( !filters.page ) filters.page = 1;
        if( !filters.pageSize ) filters.pageSize = 10;

        if ( filters.pageSize < 1 || filters.pageSize > 100 ) {
            return reject('Invalid page or pageSize');
        }

        let init = (filters.page-1) * filters.pageSize;
        let end = ((filters.page-1) * filters.pageSize) + filters.pageSize;

        let users = db.getData('/users');
        let keys = Object.keys(users);
        
        if( filters.name ) {
            let usersFiltered = {};

            for( let j = 0; j < keys.length; j++ ) {
                if( (users[keys[j]].name).toLowerCase().indexOf(filters.name.toLowerCase()) > -1 ) {
                    usersFiltered[keys[j]] = users[keys[j]];
                }
            }
            users = usersFiltered;
        }

        keys = Object.keys(users);
        let people = [];
        let hasNext = false;

        if( end > keys.length ) {
            end = keys.length;
        } else if( end < keys.length ){    
            hasNext = true;
        }
            

        for( let i = init; i < end ; i++ ) {
            let person = {
                _id: PeopleController.generateId(users[keys[i]].email),
                name: users[keys[i]].name,
                photo: users[keys[i]].photo
            }

            people.push(person);
        }

        return resolve({
            hasNext: hasNext,
            people: people
        });
    });
}


PeopleController.getPerson = function (email) {
    return new Promise( (resolve, reject) => {
        let person = db.getData('/users/' + email);

        return resolve({
            _id: ( new Buffer(person.email) ).toString('base64'),
            name: person.name,
            photo: person.photo
        });
    });
}


PeopleController.updatePerson = function (email, name, photo) {
    return new Promise( (resolve, reject) => {
        let person = db.getData('/users/' + email);
        
        if( !person ) 
            return reject("Person not found");
        
        if( name ) person.name = name;
        if( photo ) person.photo = photo;

        db.push("/users/" + email, person);

        return resolve({
            _id: ( new Buffer(person.email) ).toString('base64'),
            name: person.name,
            photo: person.photo
        });
    });
}


PeopleController.getTestimonials = function (email, filters) {
    return new Promise( (resolve, reject) => {

        if( !filters.page ) filters.page = 1;
        if( !filters.pageSize ) filters.pageSize = 10;

        if ( filters.pageSize < 1 || filters.pageSize > 100 ) {
            return reject('Invalid page or pageSize');
        }

        let init = (filters.page-1) * filters.pageSize;
        let end = ((filters.page-1) * filters.pageSize) + filters.pageSize;

        let person = db.getData('/users/' + email);
        
        let testimonials = person.testimonials;
        let hasNext = false;

        if( !testimonials || testimonials.length == 0 ) {
            return resolve({ hasNext: false, testimonials: [] });
        }

        console.log( testimonials )
        testimonials = testimonials.filter( t => t.status == filters.status );
        console.log( testimonials )

        if( end > testimonials.length ) {
            end = testimonials.length;
        } else if( end < testimonials.length ){    
            hasNext = true;
        }
        
        let testimonialsResult = [];
        for( let i = init; i < end ; i++ ) {
            let testimonial = {
                _id: testimonials[i]._id,
                status: testimonials[i].status,
                text: testimonials[i].text,
                author: testimonials[i].author,
                authorId: testimonials[i].authorId,
            }

            testimonialsResult.push(testimonial);
        }

        return resolve({
            hasNext: hasNext,
            testimonials: testimonialsResult
        });
    });
}

PeopleController.createTestimonial = function (email, testimonial) {
    return new Promise( (resolve, reject) => {

        let testimonials = [];

        try {
            testimonials = db.getData('/users/' + email + "/testimonials");
        } catch( e ) {
            console.log("primeiro depoimento");
        }

        testimonial._id = PeopleController.generateId(((new Date()).getTime()) + email);

        testimonials.push( testimonial );

        db.push("/users/" + email + "/testimonials", testimonials);

        return resolve(testimonial);
    });
}


PeopleController.approveTestimonial = function (email, idT) {
    return new Promise( (resolve, reject) => {

        let testimonials = [];

        try {
            testimonials = db.getData('/users/' + email + "/testimonials");
        } catch( e ) {
            console.log("primeiro depoimento");
        }

        for( let i = 0; i < testimonials.length; i++ ) {
            if( idT == testimonials[i]._id ) {
                testimonials[i].status = 2;

                db.push("/users/" + email + "/testimonials", testimonials);

                return resolve({
                    _id: testimonials[i]._id,
                    status: testimonials[i].status,
                    text: testimonials[i].text,
                    author: testimonials[i].author,
                    authorId: testimonials[i].authorId,
                });
            }
        }
        return reject({
            error: "Testimonial not found"
        });
    });
}


PeopleController.deleteTestimonial = function (email, idT) {
    return new Promise( (resolve, reject) => {

        let testimonials = [];

        try {
            testimonials = db.getData('/users/' + email + "/testimonials");
        } catch( e ) {
            console.log("primeiro depoimento");
        }

        let newTestimonials = [];

        newTestimonials = testimonials.filter( t => t._id != idT );

        if( newTestimonials.length < testimonials.length ) {
            db.push("/users/" + email + "/testimonials", newTestimonials);
            return resolve();
        }    else {
            return reject({
                error: "Testimonial not found"
            });
        }
        
    });
}


module.exports = PeopleController;

