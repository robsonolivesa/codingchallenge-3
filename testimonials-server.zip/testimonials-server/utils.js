var utils = utils || {};

const JsonDB = require('node-json-db');

let db;

utils.connectDB = function() {

    console.log("Configure database");
    db = new JsonDB("mainDB", true, false);
}

module.exports = utils;
