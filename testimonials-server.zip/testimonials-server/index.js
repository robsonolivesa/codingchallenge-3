'use strict';

console.log("Starts application");

let utils = require('./utils');
utils.connectDB();

console.log("Configure server");
const express = require("express");
const bodyParser = require('body-parser');

const port = 8080;
let app = express();
app.use(require('helmet')());
app.use(require('cors')());
app.use(bodyParser.urlencoded({
    extended: true
}));
app.use(bodyParser.json({
    limit: '50mb'
}));

app.use('/', require('./api/api'));
    
app.listen(port, () => {
    console.log("Up and running on " + port);
});